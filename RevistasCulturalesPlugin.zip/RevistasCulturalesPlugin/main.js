const fs = require('fs');
const path = require('path');
const Papa = require('./papaparse.min.js');

class CombinedDataPlugin {
  constructor(API, name, config) {
    this.API = API;
    this.name = name;
    this.config = config;
  }

  addEvents() {
    this.API.addEvent('afterRender', this.generateData.bind(this), 1, this);
  }

  async generateData(rendererInstance) {
    const inputDir = rendererInstance.inputDir;
    const outputDir = rendererInstance.outputDir;
    const filesOutputDir = path.join(outputDir, 'media', 'files');

    // Make sure output dir exists
    if (!fs.existsSync(filesOutputDir)) {
      fs.mkdirSync(filesOutputDir, { recursive: true });
    }

    // Helper function to process a single CSV
    const processCSV = (fileName, jsObjectName, jsFileName) => {
      const inputPath = path.join(inputDir, 'media', 'files', fileName);
      const outputPath = path.join(filesOutputDir, jsFileName);

      try {
        console.log(`[Data Plugin] Buscando CSV en: ${inputPath}`);

        if (!fs.existsSync(inputPath)) {
          console.warn(`[Data Plugin] ADVERTENCIA: ${fileName} no se encontró. Saltando.`);
          return;
        }

        let csvContent = fs.readFileSync(inputPath, 'utf8');
        csvContent = csvContent.replace(/^\uFEFF/, ''); // Remove BOM

        const parsed = Papa.parse(csvContent, {
          header: true,
          skipEmptyLines: true,
          // Normaliza los encabezados: elimina tildes y pasa a minúsculas
          transformHeader: (header) => header.normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLowerCase()
        });

        if (parsed.errors && parsed.errors.length > 0) {
          console.warn(`[Data Plugin] ADVERTENCIA de parseo en ${fileName}: ${parsed.errors[0].message}`);
        }

        // --- Image Resolution Logic for Repositories ---
        if (jsObjectName === 'REPOSITORIES_DATA') {
            const siteDomain = rendererInstance.siteConfig.domain;
            const imagesInputPath = path.join(inputDir, 'media', 'files', 'imagenes-repositorios');
            const publicMediaUrl = `${siteDomain}/media/files/imagenes-repositorios`;

            parsed.data.forEach(item => {
                if (item.id) {
                    const idStr = String(item.id).trim();
                    let images = [];
                    let thumbnails = []; // Store thumbnail paths
                    
                    const validExtensions = ['jpg', 'jpeg', 'png', 'webp'];
                    
                    for (const ext of validExtensions) {
                        const lowerPath = path.join(imagesInputPath, `${idStr}.${ext}`);
                        const upperPath = path.join(imagesInputPath, `${idStr}.${ext.toUpperCase()}`);
                        
                        let foundOriginal = null;

                        if (fs.existsSync(lowerPath)) {
                            foundOriginal = `${idStr}.${ext}`;
                        } else if (fs.existsSync(upperPath)) {
                            foundOriginal = `${idStr}.${ext.toUpperCase()}`;
                        }

                        if (foundOriginal) {
                            // Add the main image
                            images.push(`${publicMediaUrl}/${foundOriginal}`);
                            
                            // Look for the associated thumbnail
                            const thumbWebpPath = path.join(imagesInputPath, `${idStr}-thumb.webp`);
                            const thumbJpgPath = path.join(imagesInputPath, `${idStr}-thumb.jpg`);
                            
                            if (fs.existsSync(thumbWebpPath)) {
                                thumbnails.push(`${publicMediaUrl}/${idStr}-thumb.webp`);
                            } else if (fs.existsSync(thumbJpgPath)) {
                                thumbnails.push(`${publicMediaUrl}/${idStr}-thumb.jpg`);
                            } else {
                                // Fallback: Use original if no thumb is found
                                thumbnails.push(`${publicMediaUrl}/${foundOriginal}`);
                            }
                            
                            break; 
                        }
                    }
                    item.images = images;
                    item.thumbnails = thumbnails; // Expose the thumbnails array to Svelte
                }
            });
        }

        const jsContent = `window.${jsObjectName} = ${JSON.stringify(parsed.data, null, 2)};`;
        fs.writeFileSync(outputPath, jsContent, 'utf8');

        console.log(`[Data Plugin] ÉXITO: Generado ${jsFileName} con ${parsed.data.length} registros.`);

      } catch (error) {
        console.error(`[Data Plugin] ERROR FATAL procesando ${fileName}: ${error.message}`);
      }
    };

    // Process both files
    processCSV('contributors.csv', 'CONTRIBUTORS_DATA', 'contributors.js');
    processCSV('repositorios.csv', 'REPOSITORIES_DATA', 'repositories.js'); 
  }
}

module.exports = CombinedDataPlugin;